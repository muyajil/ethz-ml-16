Group MakeOurModelFitAgain:
-Mohammed Ajil
-Vincent Stettler
-Daniel Maag

1) Perform preprocessing 

Fist the MRI picture were processed with the FAST command-line program. This
yields different outputfiles, we only use the "Restored input" image, which is
again a MRI picture but corrected for spatial intensity variations (bias fields).
Website for more information on FAST: http://fsl.fmrib.ox.ac.uk/fsl/fslwiki/FAST

After this step, the new MRI images must be saved in the folder
/set_[test, train]_segmented/[train, test]_i_restore.nii.gz   for i in N

After that, extract_data_fast.py can be run to extract the data: Our best submission was
with a simplified histogram of the voxel intesities over the whole picture. This
simpified histogram maps the values of the voxels to 100 buckets.

Since we cannot easily provide the FAST test data or a script computing these
new MRI files, we supply the data file AFTER the execution of this script with
our submission. (short_histogram100_[test, test].pickle)

To reproduce the entire process, we provide the MRI data AFTER the FAST step with
the following polybox download link:

https://polybox.ethz.ch/index.php/s/cSAGevZxa1zUiac

2) Select k voxels according to 

All the voxels were processed into a histogram.

3) Train model

After that we did a grid search for the lasso model. The best performing parameter was  alpha=184.61.

4) Perform postprocessing 

None.